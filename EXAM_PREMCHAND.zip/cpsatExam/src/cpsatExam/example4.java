package cpsatExam;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class example4 {
	WebDriver wd;

	
	@Test
  public void f() throws Exception
  {
		  wd.get("https://nseindia.com/");
wd.findElement(By.id("keyword")).sendKeys("Reliance industries");
new Actions(wd).moveToElement(wd.findElement(By.id("keyword"))).sendKeys(Keys.RETURN).build().perform();;
wd.findElement(By.xpath("//*[contains(text(),'Reliance I')]")).click();

TakesScreenshot ts=(TakesScreenshot)wd;
File srcfile=ts.getScreenshotAs(OutputType.FILE);
FileUtils.copyFile(srcfile, new File("./example4.png"));

System.out.println("face value is "+wd.findElement(By.id("faceValue")).getText());
System.out.println("face value is "+wd.findElement(By.id("high52")).getText());
System.out.println("face value is "+wd.findElement(By.id("low52")).getText());


  }
  @BeforeTest
  public void beforeTest() 
  {
		System.setProperty("webdriver.chrome.driver", "/home/prajyot/Desktop/SeleniumPlugins/chromedriver");
		wd=new ChromeDriver();
		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	
  }

  @AfterTest
  public void afterTest()
  {
	  wd.quit();
  }


}
