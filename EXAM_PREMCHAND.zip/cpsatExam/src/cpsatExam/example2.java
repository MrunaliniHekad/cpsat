package cpsatExam;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class example2
{
	WebDriver wd;
  @Test
  public void f() 
  {
	  wd.get("https://nseindia.com/");
	  
	  List<WebElement> ls=wd.findElements(By.xpath("//div[@class='currencyBox']"));
	  
	  for(int i=0;i<ls.size();i++)
	  {
		  
		  System.out.println(ls.get(i).getText());
		/*  String A[]=ls.get(i).getText().split("\\s");
		  System.out.println(Integer.parseInt(A[2]));*/
		  
		  
	  }
	  List<WebElement> ls2=wd.findElements(By.xpath("//div[@class='currencyBox']/span"));
	  int price[]=new int[ls2.size()];
	  for(int i=0;i<ls.size();i++)
	  {
	 	  String t=ls2.get(i).getText();
		  int t1=Integer.parseInt(t);
		  price[i]=t1;
	  }
	  int max=price[0];
	  for(int i=0;i<ls.size();i++)
	  {
		  if(max<price[i]);
		  	max=price[i];
		  
	  }
	  
	  
	  
	  
	  
	  
  }
  @BeforeTest
  public void beforeTest() 
  {
		System.setProperty("webdriver.gecko.driver", "/home/prajyot/Desktop/SeleniumPlugins/geckodriver");
		wd=new FirefoxDriver();
		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	
  }

  @AfterTest
  public void afterTest()
  {
	  wd.quit();
  }

}
