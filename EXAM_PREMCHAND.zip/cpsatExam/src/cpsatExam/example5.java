package cpsatExam;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class example5 
{
	WebDriver wd;
  @Test
  public void f() throws Exception
  {
	  TakesScreenshot ts=(TakesScreenshot)wd;

	  FileInputStream IP=new FileInputStream("./data.xls");
	  HSSFWorkbook wb=new HSSFWorkbook(IP);
	  HSSFSheet s=wb.getSheet("Sheet1");
	  
	  for(int i=0;i<s.getLastRowNum();i++)
	  {
		String Company=  s.getRow(i).getCell(0).toString();
		  wd.get("https://nseindia.com/");


wd.findElement(By.id("keyword")).sendKeys(Company);
new Actions(wd).moveToElement(wd.findElement(By.id("keyword"))).sendKeys(Keys.RETURN).build().perform();;
wd.findElement(By.xpath("//*[contains(text(),'"+Company+"')]")).click();
System.out.println("face value is "+wd.findElement(By.id("faceValue")).getText());
File srcfile=ts.getScreenshotAs(OutputType.FILE);
FileUtils.copyFile(srcfile, new File("./example5"+Company+".png"));
Thread.sleep(2000);


		  
	  }
	  
  }
  @BeforeTest
  public void beforeTest() 
  {
		System.setProperty("webdriver.gecko.driver", "/home/prajyot/Desktop/SeleniumPlugins/geckodriver");
		wd=new FirefoxDriver();
		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	
  }

  @AfterTest
  public void afterTest()
  {
	  wd.quit();
  }

}
