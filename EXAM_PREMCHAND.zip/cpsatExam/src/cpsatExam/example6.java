package cpsatExam;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class example6 
{
	WebDriver wd;

  @Test
  public void f() 
  {
	  Actions A=new Actions(wd);
	  wd.get("https://www.shoppersstop.com/");
	  WelComePOM WL=new WelComePOM(wd);
	  WL.ClickShoe();
	  WL.ClicAllStore();
	  WL.selectCityandStoreAvailable("Mumbai");
	  
	  Assert.assertEquals(true, WL.cityCheck("Chennai"));
	  Assert.assertEquals(true, WL.cityCheck("Jaipur"));
	  Assert.assertEquals(true, WL.cityCheck("Ranchi"));
	  System.out.println(wd.getTitle());

	  
	  
	  
	  
  }
  @BeforeTest
  public void beforeTest() 
  {
		System.setProperty("webdriver.chrome.driver", "/home/prajyot/Desktop/SeleniumPlugins/chromedriver");
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--start-maximized");
		wd=new ChromeDriver(chromeOptions);
		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	
  }

  @AfterTest
  public void afterTest()
  {
	  //wd.quit();
  }

}
