package cpsatExam;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class WelComePOM 
{	WebDriver w;
Actions A;
	WelComePOM(WebDriver wd)
	{
		this.w=wd;
		A=new Actions(w);
	
	}
	By E_MEN=By.linkText("MEN");
	By E_Shoes=By.linkText("Shoes");
	By E_Store=By.xpath("//*[contains(text(),'All Stores')]");
	
	By E_ShoesCat=By.xpath("/html[1]/body[1]/main[1]/nav[1]/div[1]/div[1]/ul[1]/li[2]/div[1]/div[1]/ul[1]/li[3]/div[1]/ul[1]/li[1]/div[1]/ul[1]/li");
	By E_dropCities=By.name("cityName");
	By E_dropMyCities=By.name("pointOfServices");

	public void ClickShoe()
	{
		A.moveToElement(w.findElement(E_MEN)).build().perform();
		A.moveToElement(w.findElement(E_Shoes)).build().perform();
		List<WebElement> ls=w.findElements(E_ShoesCat);
		
		for(int i=0;i<ls.size();i++)
		{
			System.out.println(ls.get(i).getText());
		}

		
	}
	public void ClicAllStore()
	{
		w.findElement(E_Store).click();
		
	}
	
	public void selectCityandStoreAvailable(String city)
	{
		new Select(w.findElement(E_dropCities)).selectByVisibleText(city);
		System.out.println(w.findElement(E_dropMyCities).getText());
		/*Select s=new Select(w.findElement(E_dropMyCities));
		int sz=s.getOptions().size();
		for(int i=0;i<sz;i++)
		{
			System.out.println();
			
		}*/
	}
	
	public boolean cityCheck(String city)
	{
		Boolean b;
	String A=w.findElement(E_dropCities).getText();
		if(A.contains(city))
			return true;
		else
			return false;
	

	}

	
	


	
	


}
