package cpsatExam;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class example1
{

	static WebDriver wd;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception 
	{

		System.setProperty("webdriver.gecko.driver", "/home/prajyot/Desktop/SeleniumPlugins/geckodriver");
		wd=new FirefoxDriver();
		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception
	{
		wd.quit();
	}


	@Test
	public void test() throws Exception
	{
		wd.get("http://agiletestingalliance.org/");
		wd.findElement(By.linkText("Certifications")).click();
	
	List<WebElement> ls=wd.findElements(By.tagName("area"));
	int sz=ls.size();
	System.out.println("Total Number of Cerifications are "+sz);
	TakesScreenshot ts=(TakesScreenshot)wd;
	File srcfile=ts.getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(srcfile, new File("./example1_1.png"));
	
	WebElement E=wd.findElement(By.id("mat"));
	new Actions(wd).moveToElement(E).build().perform();
	
	File srcfile2=ts.getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(srcfile2, new File("./example1_2.png"));
	
	System.out.println("URL of CP MAT is "+E.getAttribute("href"));
	
	
	}

}
