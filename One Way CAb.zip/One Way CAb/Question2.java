import java.io.File;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Question2 {
	WebDriver driver;
	
  @Test
  public void f() throws Exception {
	  
	  driver.get("https://nseindia.com");
	
	  List<WebElement> ls = driver.findElements(By.xpath("//li[@class='currency active']//div[@class='boxDiv']"));
	  for(int i =0; i<ls.size(); i++) 
	  {
		
		  String text = ls.get(i).getText();
		  System.out.println(text);
		  
	  }	  
	  TakesScreenshot screen =(TakesScreenshot)driver;
	  File src = screen.getScreenshotAs(OutputType.FILE);
	  FileHandler.copy(src, new File(".\\question2_currency.png"));
	  
	  String value1=driver.findElement(By.xpath("//span[@id='us']")).getText();
	  String value2=driver.findElement(By.xpath("//span[@id='uk']")).getText();
	  String value3=driver.findElement(By.xpath("//span[@id='euro']")).getText();
	  String value4=driver.findElement(By.xpath("//span[@id='japan']")).getText();
	  String [] Value = {value1,value2, value3,value4};
	  List b = Arrays.asList(Value);
	  System.out.println(Collections.max(b));
	  
  }
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.gecko.driver", ".\\drivers\\geckodriver.exe");
	  driver = new FirefoxDriver();
	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
  }

  @AfterTest
  public void afterTest() {
	  driver.quit();
  }

}
