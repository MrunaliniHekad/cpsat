package loginregisterpom;

import org.openqa.selenium.WebDriver;

import util.LoadProperty;


public class Factory {
	protected WebDriver driver;
	protected LoadProperty property;
	public Factory(WebDriver iDriver)
	{
		this.driver=iDriver;
		property=new LoadProperty(".\\OR.property",driver);
	}
}
