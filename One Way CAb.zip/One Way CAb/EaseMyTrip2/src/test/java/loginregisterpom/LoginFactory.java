package loginregisterpom;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import loginregisterpom.Factory;


public class LoginFactory extends Factory {
	public LoginFactory(WebDriver iDriver)
	{
		super(iDriver);
	}

	public void Login (String username,String Password) throws Exception
	{
	
		WebElement ele = driver.findElement(property.getElement("HOVER1"));
		//Create object 'action' of an Actions class
		Actions action = new Actions(driver);
		//Mouseover on an element
	action.moveToElement(ele).perform();
	Thread.sleep(2000);

		driver.findElement(property.getElement("SIGN_IN")).click();
		Thread.sleep(2000);
		WebDriverWait wt=new WebDriverWait(driver, 20);
		wt.until(ExpectedConditions.visibilityOf(driver.findElement(property.getElement("EMAIL_BASIC"))));
		driver.findElement(property.getElement("EMAIL_BASIC")).sendKeys(username);;
		driver.findElement(property.getElement("PASSWORD_BASIC")).sendKeys(Password);;
		driver.findElement(property.getElement("LOGIN")).click();
	
		
		
	}
}
