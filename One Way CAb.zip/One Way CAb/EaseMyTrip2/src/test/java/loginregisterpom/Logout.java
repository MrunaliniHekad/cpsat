package loginregisterpom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Logout extends Factory {
	
	public Logout(WebDriver iDriver)
	{
		super(iDriver);
	}
	public void logout() throws Exception
	{
//		WebElement ele = driver.findElement(property.getElement("C_Hover"));
//		Actions action = new Actions(driver);
//		//Mouseover on an element
//	action.moveToElement(ele).perform();
//	Thread.sleep(2000);
	
	driver.findElement(property.getElement("C_Hover")).click();
	Thread.sleep(5000);
	driver.findElement(property.getElement("C_Logout")).click();
	Thread.sleep(5000);
    
	driver.switchTo().alert().accept();
	Thread.sleep(5000);
	driver.switchTo().alert().accept();
	Thread.sleep(3000);
	
	
	driver.get("https://www.easemytrip.com/");
}
	}


