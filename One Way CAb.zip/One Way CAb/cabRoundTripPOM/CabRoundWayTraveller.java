package cabRoundTripPOM;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;


import cabOneWayPOM.Factory;

public class CabRoundWayTraveller extends Factory {
	 public CabRoundWayTraveller(WebDriver iDriver) {
		super(iDriver);
	}

	public void cabRoundWayTraveller(String FirstName,String LastName,String PickUpAdd,String DropAdd,String Email,String Mobile) throws Exception

	{
	

		Actions action= new Actions(driver);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		//driver.get("http://seleniumhq.org");
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		driver.findElement(property.getElement("C_title")).click();
		Thread.sleep(4000);
		new Select(driver.findElement(property.getElement("C_title"))).selectByVisibleText("Mr.");
		Thread.sleep(4000);

		
		driver.findElement(property.getElement("C_FirstName")).click();
		driver.findElement(property.getElement("C_FirstName")).sendKeys(FirstName);
		
		driver.findElement(property.getElement("C_LastName")).click();
		driver.findElement(property.getElement("C_LastName")).sendKeys(LastName);
		
		
		driver.findElement(property.getElement("C_PickUpAdd")).click();
		driver.findElement(property.getElement("C_PickUpAdd")).sendKeys(PickUpAdd);
		Thread.sleep(2000);
		driver.findElement(property.getElement("C_DropAdd")).click();
		driver.findElement(property.getElement("C_DropAdd")).sendKeys(DropAdd);
		Thread.sleep(2000);
		System.out.println("Drop success");

		
		driver.findElement(property.getElement("C_Email")).click();
		driver.findElement(property.getElement("C_Email")).sendKeys(Email);
		Thread.sleep(4000);
		System.out.println("Email success");
		driver.findElement(property.getElement("C_MobileNumber")).click();
		driver.findElement(property.getElement("C_MobileNumber")).sendKeys(Mobile);
		Thread.sleep(4000);
		

		driver.findElement(property.getElement("C_Payment")).click();
			Thread.sleep(3000);	
			
			js.executeScript("window.scrollBy(0,-document.body.scrollHeight)");
			
			
			driver.findElement(property.getElement("C_Hover")).click();
			Thread.sleep(5000);
			driver.findElement(property.getElement("C_Logout")).click();
			Thread.sleep(5000);
		    
			driver.switchTo().alert().accept();
			Thread.sleep(5000);
			driver.switchTo().alert().accept();
			Thread.sleep(3000);
			System.out.println("Click on dialog box");
			
			
			driver.get("https://www.easemytrip.com/");
			Thread.sleep(3000);
			
			

			}

}
	
