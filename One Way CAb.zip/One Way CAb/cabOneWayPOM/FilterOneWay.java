package cabOneWayPOM;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import loginregisterpom.Factory;

public class FilterOneWay extends Factory {
	public FilterOneWay(WebDriver iDriver)
	{
		super(iDriver);

	}
	
	public void filter(String Source,String Destination) throws Exception
	{
		
		WebDriverWait wt=new WebDriverWait(driver, 10);
		wt.until(ExpectedConditions.visibilityOf(driver.findElement(property.getElement("E_Cabtype"))));
		Thread.sleep(3000);
		
		driver.findElement(property.getElement("E_Cabtype")).click();

		driver.findElement(property.getElement("E_AC")).click();
	
		driver.findElement(property.getElement("E_PersonType")).click();
		driver.findElement(property.getElement("E_PersonNum")).click();

		driver.findElement(property.getElement("E_BaggageType")).click();
		driver.findElement(property.getElement("E_BaggageNo")).click();

		
		driver.findElement(property.getElement("E_BookButton")).click();

	/*	Assert.assertEquals(driver.getTitle(), "Best Cab Service at Lowest Fares at EaseMyTrip.com");
		System.out.println("Travellers Details page is opened successfully");*/

	}
	}


