package cabOneWayPOM;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class Travellersdetails extends Factory {
	 public Travellersdetails(WebDriver iDriver) {
		super(iDriver);

	}

	public void travellersDetails(String FirstName,String LastName,String PickUpAdd,String DropAdd,String Email,String Mobile) throws Exception
	{
		Actions action= new Actions(driver);
		JavascriptExecutor js=(JavascriptExecutor)driver;
	
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");//scroll down to bottom
		 
		driver.findElement(property.getElement("E_title")).click();
		
		new Select(driver.findElement(property.getElement("E_title"))).selectByVisibleText("Miss.");
		driver.findElement(property.getElement("E_FirstName")).clear();
		driver.findElement(property.getElement("E_FirstName")).click();
		driver.findElement(property.getElement("E_FirstName")).sendKeys(FirstName);

		driver.findElement(property.getElement("E_LastName")).clear();
		driver.findElement(property.getElement("E_LastName")).click();
		driver.findElement(property.getElement("E_LastName")).sendKeys(LastName);
		

		driver.findElement(property.getElement("E_PickUpAdd")).clear();
		driver.findElement(property.getElement("E_PickUpAdd")).click();
		driver.findElement(property.getElement("E_PickUpAdd")).sendKeys(PickUpAdd);
	
		driver.findElement(property.getElement("E_DropAdd")).clear();
		driver.findElement(property.getElement("E_DropAdd")).click();
		driver.findElement(property.getElement("E_DropAdd")).sendKeys(DropAdd);
		
		
		System.out.println("Drop success");
		driver.findElement(property.getElement("E_Email")).clear();
		driver.findElement(property.getElement("E_Email")).click();
		driver.findElement(property.getElement("E_Email")).sendKeys(Email);
	
		
		System.out.println("Email success");
		driver.findElement(property.getElement("E_MobileNumber")).clear();
		driver.findElement(property.getElement("E_MobileNumber")).click();
		driver.findElement(property.getElement("E_MobileNumber")).sendKeys(Mobile);
		
		driver.findElement(property.getElement("E_Payment")).click();
		Thread.sleep(2000);
		
//		Assert.assertEquals(driver.getTitle(), "Best Cab Service at Lowest Fares at EaseMyTrip.com");
//		System.out.println("Payment Details page is opened successfully");	
	
		js.executeScript("window.scrollBy(0,-document.body.scrollHeight)");
		
		WebDriverWait wt=new WebDriverWait(driver, 10);
		wt.until(ExpectedConditions.visibilityOf(driver.findElement(property.getElement("E_Hover"))));

			
			driver.findElement(property.getElement("E_Hover")).click();
			Thread.sleep(5000);
			driver.findElement(property.getElement("E_Logout")).click();
			Thread.sleep(5000);
		    
			driver.switchTo().alert().accept();
			Thread.sleep(5000);
			driver.switchTo().alert().accept();
			Thread.sleep(3000);
			System.out.println("Click on dialog box");
			
			driver.get("https://www.easemytrip.com/");
			Thread.sleep(3000);
			
			
}
}
	
