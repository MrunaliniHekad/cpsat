import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.AfterTest;

public class Question5 {
	WebDriver driver;
  @Test
  public void f() throws Exception 
  {
		Actions action= new Actions(driver);
		FileInputStream IP=new FileInputStream("./Book2.xlsx");
		  XSSFWorkbook wb=new XSSFWorkbook(IP);
		  XSSFSheet s=wb.getSheet("Sheet1");
		  
		  for(int i=0;i<=s.getLastRowNum();i++)
		  {
			String company=  s.getRow(i).getCell(0).toString();
			 driver.get("https://nseindia.com");
			 System.out.println(company);
			 driver.findElement(By.id("keyword")).sendKeys(company);
			
			 new Actions(driver).moveToElement(driver.findElement(By.id("keyword"))).sendKeys(Keys.ENTER).build().perform();;
			 driver.findElement(By.xpath("//*[contains(text(),'"+company+"')]")).click();
			 System.out.println("face value is "+driver.findElement(By.id("faceValue")).getText());
			 TakesScreenshot screen =(TakesScreenshot)driver;
			  File src = screen.getScreenshotAs(OutputType.FILE);
			  FileHandler.copy(src, new File(".\\question5_"+company+".png"));  
		  }
  }
  @BeforeTest
  public void beforeTest() 
  {
	  System.setProperty("webdriver.gecko.driver", ".\\drivers\\geckodriver.exe");
	  driver = new FirefoxDriver();
	  driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
  }
  @AfterTest
  public void afterTest()
  {
	  driver.quit();
  }
}
