package Day4NG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import util.BrowserSetup;

public class Para
{
  WebDriver driver;
	@Test(dataProvider = "dp")
  public void Login(String UN, String PWD) 
  {
		driver.get("http://127.0.0.1:8080/htmldb");
		driver.findElement(By.xpath("//*[@type='text']")).sendKeys(UN);
		driver.findElement(By.xpath("//*[@type='password']")).sendKeys(PWD);
		driver.findElement(By.xpath("//*[@value='Login']")).click();
		driver.findElement(By.linkText("Logout")).click();;
		driver.findElement(By.partialLinkText("Log")).click();;
  }

  @DataProvider
  public Object[][] dp() 
  {
	  Object data[][]=new Object[5][2];
	  
	  data[0][0]="sys";
	  data[0][1]="Newuser123";
	  data[1][0]="system";
	  data[1][1]="Newuser123";
	  data[2][0]="sysddd";
	  data[2][1]="Newuser123";
	  data[3][0]="sysXYZ";
	  data[3][1]="Newuser123";
	   return data;
  }
 
  
  @BeforeTest
  public void beforeTest()
  {
	  driver=BrowserSetup.browserStart("chrome");
  }

  @AfterTest
  public void afterTest()
  {
	  driver.quit();
  }
}
